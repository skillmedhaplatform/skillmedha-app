import React from "react";

export default function Wrapper({ children }) {
  return <p style={{ color: "#27ae60" }}>{children}</p>;
}
