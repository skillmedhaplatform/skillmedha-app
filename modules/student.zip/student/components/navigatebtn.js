"use client";
import React, { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { useAppRouter } from "@/helpers/useAppRouter";
import layoutStyles from "@/app/student/(protected)/profile/profileStyles/layout.module.scss";
import { Dropdown, Tooltip } from "antd";
import { useSelector } from "react-redux";

const NavButton = ({ obj, path, notIsActive }) => {
  const studentDetails = useSelector((state) => state.student.student?.data);
  const pathname = usePathname();
  const route = useAppRouter();
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    const currentPath = pathname.split("/").pop();
    if (path !== "null") {
      const buttonPath = path.split("/").pop();
      setIsActive(currentPath === buttonPath);
    }
  }, [pathname, path]);

  const handleNavigate = () => {
    if (obj?.name === "Psychometric Test Results") {
      return;
    }
    if (obj?.path === "null" || notIsActive) {
      return route.push("/testPortal");
    }
    if (obj?.isactive) {
      return route.push(path);
    }
  };

  return (
    <button
      className={`${layoutStyles.Sidenavbtn} 
      ${!obj?.isactive ? layoutStyles.inactivebtn : ""} 
      ${isActive ? layoutStyles.activebar : ""}`}
      onClick={handleNavigate}
    >
      {obj?.name}
    </button>
  );
};

export default NavButton;
